import jmBIOTECH_2K25.jmAppBiotech;

public class App {
    public static void main(String[] args) throws Exception {
        jmAppBiotech app = new jmAppBiotech();
        app.iniciar();
        
    }
}
