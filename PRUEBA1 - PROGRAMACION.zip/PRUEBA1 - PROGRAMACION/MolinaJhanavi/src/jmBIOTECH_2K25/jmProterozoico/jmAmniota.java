package jmBIOTECH_2K25.jmProterozoico;

public class jmAmniota extends jmTetrapoda {
    public jmAmniota(){
        super();
        this.jmNombre = "Amniota";
    }
}
