package jmBIOTECH_2K25.jmProterozoico;

public class jmTetrapoda extends jmSarcopterygii {
    public jmTetrapoda(){
        super();
        this.jmNombre = "Tetrapoda";
    }
}
