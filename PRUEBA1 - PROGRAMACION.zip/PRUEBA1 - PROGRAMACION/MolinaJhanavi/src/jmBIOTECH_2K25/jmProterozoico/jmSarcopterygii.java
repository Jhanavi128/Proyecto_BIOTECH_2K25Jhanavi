package jmBIOTECH_2K25.jmProterozoico;

public class jmSarcopterygii extends jmOsteichthyes {
    public jmSarcopterygii(){
        super();
        this.jmNombre = "Sarcopterygii";
    }
}
