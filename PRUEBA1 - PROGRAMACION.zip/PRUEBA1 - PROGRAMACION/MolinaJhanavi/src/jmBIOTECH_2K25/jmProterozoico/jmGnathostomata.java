package jmBIOTECH_2K25.jmProterozoico;

public class jmGnathostomata extends jmClasificacion {
    public jmGnathostomata(){
        super("Gnathostomata");
    }

}
