package jmBIOTECH_2K25.jmProterozoico;

public class jmOsteichthyes extends jmGnathostomata {
    public jmOsteichthyes(){
        super();
        this.jmNombre = "Osteichthyes";
    }

}
